<template>
  <div class="me">
    <h3>A Family Company version 1</h3>
  </div>
</template>

<script>
export default {

}
</script>

<style>
.me {
  background-color: bisque;
}
</style>